# FUTUREGYM — Phase 1

Production-ready Next.js + TypeScript foundation for the existing FUTUREGYM concept.

## Stack

- Next.js App Router
- TypeScript
- Tailwind CSS v4
- Framer Motion
- Three.js + React Three Fiber + Drei
- PostgreSQL + Prisma-ready schema/client
- React Hook Form + Zod
- Recharts dependency and chart configuration foundation
- English / Hindi / Arabic localization architecture with Arabic RTL

## Run

```bash
pnpm install
pnpm prisma:generate
pnpm dev
```

## Verify

```bash
pnpm typecheck
pnpm lint
pnpm build
pnpm prisma:validate
```

Set `DATABASE_URL` from `.env.example` when connecting PostgreSQL. Phase 1 does not require a live database connection for the public UI.

## Production audit notes
- Authentication uses secure HTTP-only, SameSite cookies and server-side session lookup.
- Progress photos are stored outside `/public` and are served only after ownership checks.
- Admin and Pro authorization is enforced server-side.
- The included in-process auth/nutrition throttles are a single-instance safety layer; production deployments with multiple instances should replace them with a shared rate-limit store (for example Redis/Upstash) before high-traffic launch.
- Password reset token generation is implemented, but production email delivery still requires an email provider/integration; no reset token is exposed in production responses.
