import { NextRequest, NextResponse } from "next/server";
export function middleware(req:NextRequest){const protectedPath=req.nextUrl.pathname.startsWith("/dashboard")||req.nextUrl.pathname.startsWith("/admin")||req.nextUrl.pathname.startsWith("/onboarding");if(!protectedPath)return NextResponse.next();if(!req.cookies.get("futuregym_session"))return NextResponse.redirect(new URL("/login",req.url));return NextResponse.next();}
export const config={matcher:["/dashboard/:path*","/admin/:path*","/onboarding/:path*"]};
