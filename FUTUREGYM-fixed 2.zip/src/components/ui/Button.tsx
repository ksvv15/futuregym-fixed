import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Button({ children, variant = "solid", className, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "solid" | "ghost"; children: ReactNode }) {
  return <button className={cn("inline-flex min-h-11 items-center justify-center rounded-md px-5 text-sm font-semibold uppercase tracking-[.12em] transition hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-50", variant === "solid" ? "bg-accent text-black hover:bg-accent-strong" : "border border-border bg-transparent text-foreground hover:border-accent hover:text-accent", className)} {...props}>{children}</button>;
}
