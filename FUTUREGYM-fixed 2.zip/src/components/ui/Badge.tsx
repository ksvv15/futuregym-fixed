import type { ReactNode } from "react";
export function Badge({ children }: { children: ReactNode }) { return <span className="inline-flex rounded-full border border-accent-soft bg-accent/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[.18em] text-accent">{children}</span>; }
