"use client";
import type { ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  return <AnimatePresence>{open && <motion.div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 p-5 backdrop-blur-sm" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onMouseDown={(e)=>{if(e.target===e.currentTarget) onClose();}}><motion.div role="dialog" aria-modal="true" aria-label={title} className="w-full max-w-lg rounded-card border border-border bg-surface p-6 shadow-soft" initial={{opacity:0,scale:.96,y:12}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:.98,y:8}}><div className="flex items-center justify-between gap-4"><h2 className="text-xl font-semibold">{title}</h2><button type="button" onClick={onClose} className="rounded-md border border-border px-3 py-2 text-sm text-muted hover:text-foreground" aria-label="Close">×</button></div><div className="mt-5">{children}</div></motion.div></motion.div>}</AnimatePresence>;
}
