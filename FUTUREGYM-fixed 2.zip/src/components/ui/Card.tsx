import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";
export function Card({ children, className, ...props }: HTMLAttributes<HTMLDivElement> & { children: ReactNode }) { return <div className={cn("rounded-card border border-border bg-surface shadow-soft", className)} {...props}>{children}</div>; }
