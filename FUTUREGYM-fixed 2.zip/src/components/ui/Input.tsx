import type { InputHTMLAttributes } from "react";
export function Input(props: InputHTMLAttributes<HTMLInputElement>) { return <input className="w-full rounded-md border border-border bg-surface-2 px-4 py-3 text-foreground placeholder:text-muted focus:border-accent focus:outline-none" {...props} />; }
