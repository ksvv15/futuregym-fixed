import { Card } from "./Card";
export function LoadingState({ label = "Loading" }: { label?: string }) { return <Card className="p-8 text-center text-muted">{label}…</Card>; }
export function EmptyState({ title = "Nothing here yet", description = "This area is ready for future data." }: { title?: string; description?: string }) { return <Card className="p-8 text-center"><h3 className="font-semibold">{title}</h3><p className="mt-2 text-sm text-muted">{description}</p></Card>; }
export function ErrorState({ message = "Something went wrong." }: { message?: string }) { return <Card className="border-red-900/50 p-8 text-center"><h3 className="font-semibold text-red-300">Unable to load</h3><p className="mt-2 text-sm text-muted">{message}</p></Card>; }
