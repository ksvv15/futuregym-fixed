"use client";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
const FutureGymScene = dynamic(() => import("@/components/three/FutureGymScene").then((m) => m.FutureGymScene), { ssr: false, loading: () => <div aria-hidden="true" className="min-h-72 rounded-card border border-border bg-[radial-gradient(circle_at_50%_45%,rgba(255,107,53,.18),transparent_34%),#101214]" /> });
import { useMessages } from "@/components/i18n/LanguageSwitcher";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { whatsappUrl } from "@/lib/whatsapp";

const gallery = [
  ["Training floor", "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80"],
  ["Strength", "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=1200&q=80"],
  ["Movement", "https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1200&q=80"],
  ["Club atmosphere", "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?auto=format&fit=crop&w=1200&q=80"],
  ["Recovery", "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&w=1200&q=80"],
  ["Focus", "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?auto=format&fit=crop&w=1200&q=80"]
];

function Reveal({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const reduce = useReducedMotion();
  return <motion.div className={className} initial={{ opacity: 0, y: reduce ? 0 : 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.16 }} transition={{ duration: reduce ? 0 : 0.7, delay: reduce ? 0 : delay, ease: [0.22, 1, 0.36, 1] }}>{children}</motion.div>;
}

function Counter({ value }: { value: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const reduce = useReducedMotion();
  const [count, setCount] = useState(reduce ? value : 0);
  useEffect(() => {
    if (reduce) { setCount(value); return; }
    const started = performance.now();
    const timer = window.setInterval(() => {
      const progress = Math.min((performance.now() - started) / 1200, 1);
      setCount(Math.round(value * (1 - Math.pow(1 - progress, 3))));
      if (progress === 1) window.clearInterval(timer);
    }, 30);
    return () => window.clearInterval(timer);
  }, [reduce, value]);
  return <span ref={ref}>{count.toLocaleString()}</span>;
}

export function HomePage() {
  const t = useMessages();
  const reduce = useReducedMotion();
  const [heroVideo, setHeroVideo] = useState<string | null>(null);
  useEffect(() => setHeroVideo(process.env.NEXT_PUBLIC_HERO_VIDEO_URL || null), []);

  return <main className="overflow-hidden">
    <section className="relative min-h-[calc(100svh-4.5rem)] overflow-hidden border-b border-border bg-[#0b0d0f]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_35%,rgba(255,107,53,.18),transparent_32%),linear-gradient(115deg,#08090a_10%,rgba(8,9,10,.55)_55%,#0b0d0f_100%)]" />
      {heroVideo ? <video className="absolute inset-0 h-full w-full object-cover opacity-35" autoPlay muted loop playsInline poster={gallery[0][1]} src={heroVideo} /> : <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=2200&q=85')] bg-cover bg-center opacity-25" />}
      <div className="absolute inset-0 bg-black/45" />
      <Container className="relative grid min-h-[calc(100svh-4.5rem)] items-center gap-12 py-16 lg:grid-cols-[1.02fr_.98fr]">
        <motion.div initial={{ opacity: 0, y: reduce ? 0 : 36 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reduce ? 0 : .9, ease: [.22,1,.36,1] }}>
          <p className="mb-5 text-xs font-semibold uppercase tracking-[.28em] text-accent">{t.hero.eyebrow}</p>
          <h1 className="max-w-4xl text-6xl font-black leading-[.92] tracking-[-.06em] md:text-8xl">{t.hero.title}</h1>
          <p className="mt-7 max-w-2xl text-base leading-7 text-white/65 md:text-lg md:leading-8">{t.hero.body}</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/signup"><Button>{t.hero.join}</Button></Link>
            <Link href="/membership"><Button variant="ghost">{t.hero.membership}</Button></Link>
            <a href={whatsappUrl(t.whatsapp.join)} target="_blank" rel="noreferrer"><Button variant="ghost">{t.hero.whatsapp}</Button></a>
          </div>
          <a href="#about" className="mt-12 inline-flex items-center gap-3 text-xs uppercase tracking-[.22em] text-white/45 transition hover:text-white"><span className="h-px w-10 bg-accent" />{t.hero.scroll}</a>
        </motion.div>
        <motion.div initial={{ opacity: 0, scale: reduce ? 1 : .94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: reduce ? 0 : 1, delay: reduce ? 0 : .15 }} className="relative">
          <FutureGymScene />
          <div className="pointer-events-none absolute -bottom-4 left-4 right-4 h-20 rounded-full bg-accent/10 blur-3xl" />
        </motion.div>
      </Container>
    </section>

    <section id="about" className="py-24 md:py-32"><Container className="grid gap-12 lg:grid-cols-[.85fr_1.15fr] lg:items-end"><Reveal><SectionHeading eyebrow={t.sections.aboutEyebrow} title={t.sections.aboutTitle}>{t.sections.aboutBody}</SectionHeading><Link href="/about" className="mt-8 inline-flex text-sm font-semibold uppercase tracking-[.15em] text-accent">{t.sections.aboutCta} →</Link></Reveal><Reveal delay={.1} className="grid gap-4 sm:grid-cols-2"><div className="relative min-h-72 overflow-hidden rounded-card border border-border"><Image src={gallery[3][1]} alt={t.sections.gallery[3]} fill sizes="(max-width: 640px) 100vw, 50vw" className="object-cover" loading="lazy" /></div><div className="grid gap-4"><div className="rounded-card border border-border bg-surface p-7"><p className="text-4xl font-black tracking-tight">01</p><p className="mt-4 text-sm leading-6 text-muted">{t.sections.aboutDetail1}</p></div><div className="rounded-card border border-border bg-surface-2 p-7"><p className="text-sm uppercase tracking-[.18em] text-accent">{t.sections.readyLabel}</p><p className="mt-4 text-sm leading-6 text-muted">{t.sections.aboutDetail2}</p></div></div></Reveal></Container></section>

    <section id="services" className="border-y border-border bg-surface/40 py-24 md:py-32"><Container><Reveal><SectionHeading eyebrow={t.sections.servicesEyebrow} title={t.sections.servicesTitle}>{t.sections.servicesBody}</SectionHeading></Reveal><div className="mt-12 grid gap-5 md:grid-cols-2"><Reveal><ServiceCard title={t.sections.gym} body={t.sections.gymBody} image={gallery[0][1]} index="01" /></Reveal><Reveal delay={.08}><ServiceCard title={t.sections.yoga} body={t.sections.yogaBody} image={gallery[2][1]} index="02" /></Reveal></div></Container></section>

    <section className="py-24 md:py-32"><Container><Reveal><SectionHeading eyebrow={t.sections.whyEyebrow} title={t.sections.whyTitle} /></Reveal><div className="mt-12 grid gap-3 md:grid-cols-2 lg:grid-cols-4">{t.sections.whyItems.map((item, i) => <Reveal key={item} delay={i * .06}><motion.div whileHover={{ y: reduce ? 0 : -5 }} className="group rounded-card border border-border bg-surface p-6 transition hover:border-accent/50"><span className="text-xs text-accent">0{i + 1}</span><p className="mt-14 text-lg font-semibold">{item}</p><div className="mt-8 h-px w-10 bg-border transition-all group-hover:w-full group-hover:bg-accent" /></motion.div></Reveal>)}</div></Container></section>

    <section id="membership" className="border-y border-border bg-[#101315] py-24 md:py-32"><Container><Reveal><SectionHeading eyebrow={t.sections.membershipEyebrow} title={t.sections.membershipTitle}>{t.sections.membershipBody}</SectionHeading></Reveal><div className="mt-12 grid gap-5 md:grid-cols-3">{([t.sections.basic,t.sections.pro,t.sections.elite] as const).map((tier, i) => <Reveal key={tier} delay={i * .07}><MembershipCard tier={tier} body={t.sections.from} cta={t.sections.membershipCta} message={t.whatsapp.membership.replace("{tier}", tier)} highlighted={tier === t.sections.pro} popularLabel={t.sections.popular} whatsappLabel={t.sections.whatsapp} /></Reveal>)}</div></Container></section>

    <section className="py-24 md:py-32"><Container className="grid gap-14 lg:grid-cols-[1.1fr_.9fr] lg:items-center"><Reveal><SectionHeading eyebrow={t.sections.transformationEyebrow} title={t.sections.transformationTitle}>{t.sections.transformationBody}</SectionHeading><div className="mt-10 grid grid-cols-3 gap-3">{[t.sections.strength,t.sections.mobility,t.sections.consistency].map((x, i) => <div key={x} className="rounded-card border border-border bg-surface p-5"><p className="text-2xl font-black"><Counter value={[86,74,92][i]} />%</p><p className="mt-2 text-[11px] uppercase tracking-[.15em] text-muted">{x}</p></div>)}</div></Reveal><Reveal delay={.1}><div className="relative overflow-hidden rounded-card border border-border bg-surface p-4"><div className="rounded-[calc(var(--radius)-.25rem)] border border-border bg-background p-6"><div className="flex items-center justify-between border-b border-border pb-5"><div><p className="text-xs uppercase tracking-[.18em] text-accent">{t.sections.progress}</p><p className="mt-2 text-2xl font-bold">{t.sections.progressCard}</p></div><span className="text-xs text-muted">{t.sections.liveReady}</span></div><div className="mt-7 space-y-5">{[[t.sections.strength,82],[t.sections.mobility,68],[t.sections.consistency,91]].map(([label,val])=><div key={label as string}><div className="mb-2 flex justify-between text-xs"><span>{label}</span><span className="text-muted">{val}%</span></div><div className="h-2 overflow-hidden rounded-full bg-surface-2"><motion.div initial={{ width: 0 }} whileInView={{ width: `${val}%` }} viewport={{ once: true }} transition={{ duration: 1 }} className="h-full rounded-full bg-accent" /></div></div>)}</div></div></div></Reveal></Container></section>

    <section className="border-y border-border bg-surface/35 py-24 md:py-32"><Container><Reveal><SectionHeading eyebrow={t.sections.galleryEyebrow} title={t.sections.galleryTitle}>{t.sections.galleryBody}</SectionHeading></Reveal><div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-3">{gallery.map(([, src], i) => <Reveal key={src} delay={(i % 3) * .05}><div className={`group relative overflow-hidden rounded-card border border-border ${i === 0 ? "aspect-[4/5]" : "aspect-[4/3]"}`}><Image src={src} alt={t.sections.gallery[i]} fill sizes="(max-width: 768px) 50vw, 33vw" className="object-cover transition duration-700 group-hover:scale-105" loading="lazy"/><div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-70"/><span className="absolute bottom-4 left-4 text-[10px] uppercase tracking-[.18em] text-white/70">{t.sections.gallery[i]}</span></div></Reveal>)}</div></Container></section>

    <section className="py-24 md:py-32"><Container><Reveal><SectionHeading eyebrow={t.sections.reviewsEyebrow} title={t.sections.reviewsTitle} /></Reveal><div className="mt-12 grid gap-5 lg:grid-cols-[.7fr_1.3fr]"><Reveal><div className="rounded-card border border-border bg-surface p-8"><div className="text-accent">★★★★★</div><div className="mt-4 text-6xl font-black">{t.sections.rating}</div><div className="mt-2 text-sm text-muted">{t.sections.reviews}</div></div></Reveal><div className="grid gap-4 md:grid-cols-3">{[t.sections.review1,t.sections.review2,t.sections.review3].map((review, i) => <Reveal key={review} delay={i * .06}><Card className="h-full p-7"><div className="text-xs text-accent">★★★★★</div><p className="mt-6 text-sm leading-7 text-white/75">“{review}”</p><p className="mt-8 text-[10px] uppercase tracking-[.16em] text-muted">{t.sections.verified} / {i + 1}</p></Card></Reveal>)}</div></div></Container></section>

    <section className="border-y border-border bg-[#0e1113] py-24 md:py-32"><Container><Reveal><div className="relative overflow-hidden rounded-card border border-border p-8 md:p-14"><div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,107,53,.2),transparent_35%)]"/><div className="relative max-w-3xl"><p className="text-xs uppercase tracking-[.25em] text-accent">{t.sections.dubaiEyebrow}</p><h2 className="mt-5 text-4xl font-black tracking-[-.04em] md:text-6xl">{t.sections.dubaiTitle}</h2><p className="mt-6 max-w-xl text-base leading-7 text-muted">{t.sections.dubaiBody}</p><div className="mt-8 flex flex-wrap items-center gap-4"><span className="rounded-full border border-border bg-background/70 px-4 py-2 text-xs uppercase tracking-[.12em]">{t.sections.location}</span><span className="text-xs text-muted">{t.sections.directions}</span></div></div></div></Reveal></Container></section>

    <section id="contact" className="py-24 md:py-32"><Container className="grid gap-10 lg:grid-cols-[1fr_auto] lg:items-end"><Reveal><SectionHeading eyebrow={t.sections.contactEyebrow} title={t.sections.contactTitle}>{t.sections.contactBody}</SectionHeading></Reveal><Reveal delay={.1}><div className="flex flex-wrap gap-3"><Link href="/contact"><Button>{t.sections.contactCta}</Button></Link><a href={whatsappUrl(t.whatsapp.contact)} target="_blank" rel="noreferrer"><Button variant="ghost">{t.hero.whatsapp}</Button></a></div></Reveal></Container></section>

    <section className="relative overflow-hidden border-t border-border bg-accent py-24 text-black"><Container><Reveal><p className="text-xs font-bold uppercase tracking-[.25em]">{t.sections.finalEyebrow}</p><div className="mt-4 flex flex-col justify-between gap-8 md:flex-row md:items-end"><h2 className="max-w-4xl text-5xl font-black leading-none tracking-[-.06em] md:text-8xl">{t.sections.finalTitle}</h2><Link href="/signup" className="inline-flex min-h-11 shrink-0 items-center justify-center rounded-md border border-black/20 bg-black px-6 text-sm font-bold uppercase tracking-[.12em] text-white transition hover:-translate-y-0.5">{t.sections.finalCta}</Link></div></Reveal></Container></section>
  </main>;
}

function ServiceCard({ title, body, image, index }: { title: string; body: string; image: string; index: string }) {
  const reduce = useReducedMotion();
  return <motion.div whileHover={{ y: reduce ? 0 : -6 }} className="group relative min-h-[28rem] overflow-hidden rounded-card border border-border bg-surface"><Image src={image} alt={title} fill sizes="(max-width: 768px) 100vw, 50vw" className="object-cover opacity-60 transition duration-700 group-hover:scale-105 group-hover:opacity-75" loading="lazy"/><div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"/><div className="absolute inset-x-0 bottom-0 p-7 md:p-9"><span className="text-xs uppercase tracking-[.2em] text-accent">{index}</span><h3 className="mt-3 text-4xl font-black">{title}</h3><p className="mt-3 max-w-xl text-sm leading-6 text-white/65">{body}</p></div></motion.div>;
}
function MembershipCard({ tier, body, cta, message, highlighted, popularLabel, whatsappLabel }: { tier: string; body: string; cta: string; message: string; highlighted?: boolean; popularLabel: string; whatsappLabel: string }) {
  return <motion.div whileHover={{ y: -5 }} className={`rounded-card border p-7 transition ${highlighted ? "border-accent bg-accent/10" : "border-border bg-surface"}`}><div className="flex items-center justify-between"><h3 className="text-2xl font-bold">{tier}</h3>{highlighted && <span className="rounded-full bg-accent px-3 py-1 text-[9px] font-bold uppercase tracking-[.15em] text-black">{popularLabel}</span>}</div><div className="mt-10 h-14"><p className="text-xs uppercase tracking-[.15em] text-muted">{body}</p></div><div className="mt-8 flex gap-2"><Link href="/membership" className="inline-flex min-h-11 flex-1 items-center justify-center rounded-md border border-border px-4 text-xs font-semibold uppercase tracking-[.1em] transition hover:border-accent">{cta}</Link><a href={whatsappUrl(message)} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center justify-center rounded-md bg-accent px-4 text-xs font-semibold uppercase tracking-[.1em] text-black">{whatsappLabel}</a></div></motion.div>;
}
