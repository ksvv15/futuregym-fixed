"use client";
import { motion } from "framer-motion";
export function AdminHeader({title,subtitle}:{title:string;subtitle:string}){return <header className="mb-6"><p className="text-[10px] font-semibold uppercase tracking-[.24em] text-accent">Future Gym / Admin</p><h1 className="mt-2 text-3xl font-bold md:text-4xl">{title}</h1><p className="mt-2 text-sm text-muted">{subtitle}</p></header>}
export function StatCard({label,value,detail}:{label:string;value:string|number;detail?:string}){return <motion.div initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} className="rounded-card border border-border bg-surface p-5 shadow-premium"><p className="text-xs uppercase tracking-[.16em] text-muted">{label}</p><p className="mt-3 text-3xl font-bold">{value}</p>{detail&&<p className="mt-2 text-xs text-muted">{detail}</p>}</motion.div>}
export function Panel({children,className='' }:{children:React.ReactNode;className?:string}){return <div className={`rounded-card border border-border bg-surface shadow-premium ${className}`}>{children}</div>}
export function EmptyState({text='No records found.'}:{text?:string}){return <div className="p-10 text-center text-sm text-muted">{text}</div>}
