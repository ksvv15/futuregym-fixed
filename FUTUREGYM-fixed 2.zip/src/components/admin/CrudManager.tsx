"use client";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion } from "framer-motion";

const schemas = {
  memberships: z.object({ name:z.string().min(2), tier:z.enum(["BASIC","PRO","ELITE"]), price:z.coerce.number().min(0), durationDays:z.coerce.number().int().positive(), benefits:z.string().min(2), proFeatures:z.string().optional() }),
  exercises: z.object({ name:z.string().min(2), muscleGroup:z.string().min(2), difficulty:z.string().min(2), instructions:z.string().min(2) }),
  food: z.object({ name:z.string().min(2), calories100:z.coerce.number().min(0), protein100:z.coerce.number().min(0), carbs100:z.coerce.number().min(0), fat100:z.coerce.number().min(0), fiber100:z.coerce.number().min(0) }),
  reviews: z.object({ name:z.string().min(2), rating:z.coerce.number().int().min(1).max(5), text:z.string().min(3) }),
  gallery: z.object({ type:z.enum(["image","video"]), url:z.string().url(), alt:z.string().min(2) }),
  content: z.object({ key:z.string().min(2), value:z.string().min(2) })
};
type Kind = keyof typeof schemas;
const titles:Record<Kind,string>={memberships:"membership plan",exercises:"exercise",food:"food item",reviews:"review",gallery:"gallery item",content:"content item"};

export function CrudManager({kind}:{kind:Kind}) {
  const [rows,setRows]=useState<any[]>([]); const [editing,setEditing]=useState<any>(null); const [open,setOpen]=useState(false); const [query,setQuery]=useState(""); const [notice,setNotice]=useState("");
  const {register,handleSubmit,reset,formState:{errors}}=useForm({resolver:zodResolver(schemas[kind]),defaultValues:{tier:"BASIC",rating:5,type:"image"}});
  async function load(){const r=await fetch(`/api/admin/${kind}`,{cache:"no-store"});if(r.ok)setRows(await r.json());}
  useEffect(()=>{load()},[]);
  function edit(row:any){setEditing(row);reset({...row,benefits:JSON.stringify(row.benefits??[]),proFeatures:JSON.stringify(row.proFeatures??[]),value:JSON.stringify(row.value??{})});setOpen(true);}
  async function submit(data:any){const payload:any={...data};if(kind==="memberships"){try{payload.benefits=JSON.parse(data.benefits);payload.proFeatures=JSON.parse(data.proFeatures||"[]")}catch{return setNotice("Benefits must be valid JSON.")}}if(kind==="content"){try{payload.value=JSON.parse(data.value)}catch{return setNotice("Value must be valid JSON.")}}const r=await fetch(`/api/admin/${kind}`,{method:editing?"PUT":"POST",headers:{"content-type":"application/json"},body:JSON.stringify(editing?{...payload,id:editing.id}:payload)});setNotice(r.ok?"Saved successfully.":"Unable to save.");if(r.ok){setOpen(false);setEditing(null);reset();load();}}
  async function remove(id:string){const r=await fetch(`/api/admin/${kind}`,{method:"DELETE",headers:{"content-type":"application/json"},body:JSON.stringify({id})});if(r.ok)load();else setNotice("Unable to delete.");}
  async function toggle(id:string,active:boolean){const r=await fetch(`/api/admin/${kind}`,{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({id,active:!active})});if(r.ok)load();}
  const filtered=rows.filter(r=>JSON.stringify(r).toLowerCase().includes(query.toLowerCase()));
  const fields=Object.keys((schemas[kind] as any).shape) as string[];
  return <div>
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:justify-between"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search…" className="rounded-xl border border-border bg-surface px-4 py-3 text-sm sm:w-80"/><button onClick={()=>{setEditing(null);reset();setOpen(true)}} className="rounded-xl bg-accent px-4 py-3 text-sm font-semibold text-black">Create {titles[kind]}</button></div>
    <div className="overflow-hidden rounded-card border border-border bg-surface">{filtered.map(r=><motion.div layout key={r.id} className="grid gap-3 border-b border-border px-5 py-4 md:grid-cols-[1.5fr_1fr_auto_auto] md:items-center"><div><p className="font-medium">{r.name??r.key}</p><p className="text-xs text-muted">{r.tier??r.type??(r.rating?`${r.rating}/5`:"")}</p></div><p className="truncate text-xs text-muted">{kind==="memberships"?`${r.price} · ${r.durationDays} days`:kind==="food"?`${r.calories100} kcal / 100g`:kind==="reviews"?r.text:kind==="gallery"?r.url:"Managed content"}</p><span className="text-xs text-muted">{r.active===false?"Inactive":"Active"}</span><div className="flex gap-2"><button onClick={()=>edit(r)} className="rounded-lg border border-border px-3 py-2 text-xs">Edit</button><button onClick={()=>toggle(r.id,r.active!==false)} className="rounded-lg border border-border px-3 py-2 text-xs">{r.active===false?"Activate":"Deactivate"}</button>{kind==="exercises"&&<button onClick={()=>remove(r.id)} className="rounded-lg border border-red-500/30 px-3 py-2 text-xs text-red-400">Delete</button>}</div></motion.div>)}{filtered.length===0&&<div className="p-10 text-center text-sm text-muted">No records found.</div>}</div>
    {notice&&<p className="mt-3 text-sm text-accent">{notice}</p>}
    <AnimatePresence>{open&&<motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"><motion.div initial={{y:20,scale:.98}} animate={{y:0,scale:1}} className="max-h-[90vh] w-full max-w-2xl overflow-auto rounded-2xl border border-border bg-surface p-6"><div className="mb-5 flex items-center justify-between"><h2 className="text-xl font-semibold">{editing?"Edit":"Create"} {titles[kind]}</h2><button onClick={()=>setOpen(false)} className="text-sm text-muted">Close</button></div><form onSubmit={handleSubmit(submit)} className="grid gap-4 md:grid-cols-2">{fields.map(field=><label key={field} className={['text','instructions','benefits','proFeatures','value','url'].includes(field)?'md:col-span-2':''}><span className="mb-1 block text-xs uppercase tracking-wider text-muted">{field}</span>{['text','instructions','benefits','proFeatures','value'].includes(field)?<textarea {...register(field)} rows={4} className="w-full rounded-xl border border-border bg-surface-2 px-3 py-3 text-sm"/>:<input {...register(field)} type={['price','durationDays','rating','calories100','protein100','carbs100','fat100','fiber100'].includes(field)?'number':'text'} className="w-full rounded-xl border border-border bg-surface-2 px-3 py-3 text-sm"/>}{errors[field]&&<span className="text-xs text-red-400">Invalid value</span>}</label>)}<div className="md:col-span-2 flex justify-end gap-2"><button type="button" onClick={()=>setOpen(false)} className="rounded-xl border border-border px-4 py-3 text-sm">Cancel</button><button className="rounded-xl bg-accent px-4 py-3 text-sm font-semibold text-black">Save</button></div></form></motion.div></motion.div>}</AnimatePresence>
  </div>;
}
