"use client";
import type { ReactNode } from "react";
import { motion, useReducedMotion } from "framer-motion";
export function PageTransition({ children }: { children: ReactNode }) { const reduce = useReducedMotion(); return <motion.div initial={{opacity:0,y:reduce?0:8}} animate={{opacity:1,y:0}} transition={{duration:reduce?0:.35,ease:"easeOut"}}>{children}</motion.div>; }
