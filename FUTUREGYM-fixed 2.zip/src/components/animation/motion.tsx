"use client";

import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";
import { motionTransition, motionVariants } from "@/lib/animation/motion";

export function FadeIn({ children, className = "" }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return <motion.div className={className} variants={motionVariants.fadeIn} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.15 }} transition={reduce ? { duration: 0 } : motionTransition}>{children}</motion.div>;
}

export function SlideUp({ children, className = "" }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return <motion.div className={className} variants={motionVariants.slideUp} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.15 }} transition={reduce ? { duration: 0 } : motionTransition}>{children}</motion.div>;
}

export function Stagger({ children, className = "" }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return <motion.div className={className} variants={motionVariants.stagger} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.1 }} transition={reduce ? { duration: 0 } : undefined}>{children}</motion.div>;
}
