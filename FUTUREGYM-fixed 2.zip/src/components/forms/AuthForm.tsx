"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, signupSchema, type LoginInput, type SignupInput } from "@/lib/validation/auth";
import { useMessages } from "@/components/i18n/LanguageSwitcher";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const t = useMessages();
  const schema = mode === "login" ? loginSchema : signupSchema;
  const form = useForm<LoginInput & Partial<SignupInput>>({ resolver: zodResolver(schema), defaultValues: { name: "", email: "", password: "" } });
  const errorText = (key?: string) => key === "validation.email" ? t.foundation.validEmail : key === "validation.password" ? t.foundation.minPassword : key === "validation.name" ? t.foundation.enterName : key;
  return <form onSubmit={form.handleSubmit(() => undefined)} className="space-y-5">
    {mode === "signup" && <Field label={t.foundation.name} error={errorText(form.formState.errors.name?.message)}><Input {...form.register("name")} placeholder={t.foundation.yourName} /></Field>}
    <Field label={t.foundation.email} error={errorText(form.formState.errors.email?.message)}><Input {...form.register("email")} type="email" placeholder={t.foundation.emailPlaceholder} /></Field>
    <Field label={t.foundation.password} error={errorText(form.formState.errors.password?.message)}><Input {...form.register("password")} type="password" placeholder={t.foundation.passwordPlaceholder} /></Field>
    <Button className="w-full" type="submit">{mode === "login" ? t.foundation.login : t.foundation.createAccount}</Button>
  </form>;
}
function Field({label,error,children}:{label:string;error?:string;children:React.ReactNode}){return <label className="block space-y-2 text-xs font-semibold uppercase tracking-[.12em]"><span>{label}</span>{children}{error&&<span className="block text-xs normal-case tracking-normal text-red-300">{error}</span>}</label>}
