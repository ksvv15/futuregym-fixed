"use client";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, OrbitControls, RoundedBox } from "@react-three/drei";
import { useEffect, useRef, useState } from "react";
import type { Group } from "three";

function Barbell() {
  const ref = useRef<Group>(null);
  useFrame((_, delta) => { if (ref.current) ref.current.rotation.y += delta * 0.22; });
  return <group ref={ref}><mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.07, 0.07, 3.8, 24]} /><meshStandardMaterial metalness={0.9} roughness={0.22} color="#c7c9cc" /></mesh>{[-1.55,1.55].map((x) => <mesh key={x} position={[x,0,0]} rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[0.7,0.7,0.22,32]} /><meshStandardMaterial metalness={0.8} roughness={0.28} color="#202326" /></mesh>)}<mesh position={[0,0,0.02]} rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[0.16,0.16,0.25,24]} /><meshStandardMaterial metalness={0.95} roughness={0.16} color="#ff6b35" /></mesh></group>;
}
function Scene() { return <><ambientLight intensity={0.8} /><directionalLight position={[3,4,5]} intensity={2.2} /><Float speed={1.2} rotationIntensity={0.16} floatIntensity={0.2}><Barbell /></Float><RoundedBox args={[6.5,0.06,3.4]} radius={0.08} smoothness={3} position={[0,-1.2,0]}><meshStandardMaterial color="#14171a" metalness={0.5} roughness={0.55} /></RoundedBox><Environment preset="warehouse" /></>; }
export function FutureGymScene() {
  const [supported, setSupported] = useState(true);
  useEffect(() => { try { const mobile = window.matchMedia("(max-width: 767px)").matches; const c = document.createElement("canvas"); setSupported(!mobile && Boolean(c.getContext("webgl") || c.getContext("experimental-webgl"))); } catch { setSupported(false); } }, []);
  if (!supported) return <div aria-hidden="true" className="grid-noise h-full min-h-72 rounded-card border border-border bg-[radial-gradient(circle_at_50%_45%,rgba(255,107,53,.18),transparent_34%),#101214]" />;
  return <div className="h-full min-h-72 overflow-hidden rounded-card border border-border bg-[#101214]"><Canvas camera={{ position: [0, 0.3, 6.3], fov: 38 }} dpr={[1, 1.5]} gl={{ antialias: true, alpha: true }}><Scene /><OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.35} /></Canvas></div>;
}
