"use client";
import { Container } from "@/components/ui/Container";
import { useMessages } from "@/components/i18n/LanguageSwitcher";
export function Footer() { const t = useMessages(); return <footer className="border-t border-border py-10"><Container className="flex flex-col gap-3 text-xs text-muted sm:flex-row sm:items-center sm:justify-between"><span>{t.footer.line1}</span><span>{t.footer.line2}</span></Container></footer>; }
