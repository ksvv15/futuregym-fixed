"use client";
import { useRouter } from "next/navigation"; import { Button } from "@/components/ui/Button"; import { useMessages } from "@/components/i18n/LanguageSwitcher";
export function LogoutButton(){const router=useRouter();const t=useMessages();return <Button variant="ghost" onClick={async()=>{await fetch("/api/auth/logout",{method:"POST"});router.push("/");router.refresh();}}>{t.phase3.auth.logout}</Button>}
