export const phase5Messages = {
  en: {
    title:"Nutrition dashboard", subtitle:"Fuel your training with clarity.", estimateNotice:"Nutrition targets and food values are estimates, not medical advice.",
    metrics:{calories:"Calories",protein:"Protein",carbs:"Carbohydrates",fat:"Fat"},
    foodTracker:{title:"AI food tracker",helper:"Describe a meal naturally in English, Hindi, or Arabic.",placeholder:"What did you eat? e.g. I ate 2 eggs, 2 rotis and 250 ml milk.",interpret:"Interpret food",summary:"Estimated nutritional summary",save:"Save meal"},
    voice:{button:"LOG FOOD BY VOICE",listening:"Listening…",unsupported:"Voice input is not supported on this device. Use text instead.",error:"Voice recognition failed. Please use text instead."},
    chart:{title:"Seven-day intake",subtitle:"Estimated calories logged per day."},
    effect:{title:"Food effect",energy:"Energy contribution from the meal supports daily activity and training.",protein:"Protein contributes to daily protein intake and recovery-focused nutrition.",fiber:"Fiber is shown when the estimate can identify it; whole foods often contribute useful fiber.",goal:"Portion suitability depends on your target, total daily intake, and the rest of your meals."},
    history:{title:"Meal history",entries:"entries",empty:"No meals logged today yet."},
    common:{working:"Working…",saved:"Meal saved successfully.",saveError:"Could not save this meal.",loadError:"Could not load nutrition data."}
  },
  hi: {
    title:"न्यूट्रिशन डैशबोर्ड", subtitle:"ट्रेनिंग को बेहतर ईंधन दें।", estimateNotice:"न्यूट्रिशन लक्ष्य और भोजन के मान अनुमानित हैं, मेडिकल सलाह नहीं।",
    metrics:{calories:"कैलोरी",protein:"प्रोटीन",carbs:"कार्बोहाइड्रेट",fat:"फैट"},
    foodTracker:{title:"AI फूड ट्रैकर",helper:"अंग्रेज़ी, हिंदी या अरबी में सामान्य तरीके से भोजन लिखें।",placeholder:"आपने क्या खाया? जैसे: मैंने 2 अंडे, 2 रोटी और 250 ml दूध खाया।",interpret:"भोजन समझें",summary:"अनुमानित न्यूट्रिशन सारांश",save:"भोजन सेव करें"},
    voice:{button:"आवाज़ से भोजन लॉग करें",listening:"सुन रहा है…",unsupported:"इस डिवाइस पर वॉइस इनपुट उपलब्ध नहीं है। टेक्स्ट इस्तेमाल करें।",error:"वॉइस रिकग्निशन विफल हुआ। टेक्स्ट इस्तेमाल करें।"},
    chart:{title:"सात दिन का सेवन",subtitle:"हर दिन लॉग की गई अनुमानित कैलोरी।"},
    effect:{title:"भोजन का असर",energy:"भोजन से मिलने वाली ऊर्जा दैनिक गतिविधि और ट्रेनिंग में योगदान देती है।",protein:"प्रोटीन आपके दैनिक प्रोटीन सेवन और रिकवरी-केंद्रित पोषण में योगदान देता है।",fiber:"जहाँ अनुमान संभव हो वहाँ फाइबर दिखाया जाता है; संपूर्ण खाद्य पदार्थ उपयोगी फाइबर दे सकते हैं।",goal:"पोर्टियन आपके लक्ष्य, कुल दैनिक सेवन और बाकी भोजन पर निर्भर करती है।"},
    history:{title:"भोजन इतिहास",entries:"एंट्री",empty:"आज अभी कोई भोजन लॉग नहीं है।"},
    common:{working:"काम हो रहा है…",saved:"भोजन सफलतापूर्वक सेव हुआ।",saveError:"भोजन सेव नहीं हो सका।",loadError:"न्यूट्रिशन डेटा लोड नहीं हो सका।"}
  },
  ar: {
    title:"لوحة التغذية", subtitle:"غذِّ تدريبك بوضوح.", estimateNotice:"أهداف التغذية وقيم الطعام تقديرية وليست نصيحة طبية.",
    metrics:{calories:"السعرات",protein:"البروتين",carbs:"الكربوهيدرات",fat:"الدهون"},
    foodTracker:{title:"متتبع الطعام بالذكاء الاصطناعي",helper:"صف وجبتك بشكل طبيعي بالعربية أو الإنجليزية أو الهندية.",placeholder:"ماذا أكلت؟ مثال: تناولت بيضتين وروتيَين و250 مل من الحليب.",interpret:"تفسير الطعام",summary:"ملخص غذائي تقديري",save:"حفظ الوجبة"},
    voice:{button:"تسجيل الطعام بالصوت",listening:"جارٍ الاستماع…",unsupported:"الإدخال الصوتي غير مدعوم على هذا الجهاز. استخدم النص.",error:"فشل التعرف الصوتي. استخدم النص بدلاً منه."},
    chart:{title:"تناول آخر سبعة أيام",subtitle:"السعرات التقديرية المسجلة يومياً."},
    effect:{title:"تأثير الطعام",energy:"تساهم الطاقة في الوجبة في دعم النشاط اليومي والتدريب.",protein:"يساهم البروتين في إجمالي البروتين اليومي والتغذية الداعمة للتعافي.",fiber:"يظهر الألياف عندما يمكن تقديرها؛ وقد توفر الأطعمة الكاملة كمية مفيدة منها.",goal:"ملاءمة الحصة تعتمد على هدفك وإجمالي تناولك اليومي وبقية وجباتك."},
    history:{title:"سجل الوجبات",entries:"إدخالات",empty:"لا توجد وجبات مسجلة اليوم بعد."},
    common:{working:"جارٍ العمل…",saved:"تم حفظ الوجبة بنجاح.",saveError:"تعذر حفظ الوجبة.",loadError:"تعذر تحميل بيانات التغذية."}
  }
} as const;
