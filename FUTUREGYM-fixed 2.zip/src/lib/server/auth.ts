import "server-only";
import crypto from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/server/prisma";

export const SESSION_COOKIE = "futuregym_session";
const SESSION_DAYS = 30;
const RESET_HOURS = 1;

function hash(value: string) { return crypto.createHash("sha256").update(value).digest("hex"); }
export async function makePasswordHash(password: string) { const salt=crypto.randomBytes(16); const derived=await new Promise<Buffer>((resolve,reject)=>crypto.scrypt(password,salt,64,(e,d)=>e?reject(e):resolve(d))); return `scrypt:${salt.toString("hex")}:${derived.toString("hex")}`; }
export async function checkPassword(password: string, stored: string) { const [,saltHex,hashHex]=stored.split(":"); if(!saltHex||!hashHex)return false; const derived=await new Promise<Buffer>((resolve,reject)=>crypto.scrypt(password,Buffer.from(saltHex,"hex"),64,(e,d)=>e?reject(e):resolve(d))); return crypto.timingSafeEqual(Buffer.from(hashHex,"hex"),derived); }

export async function createSession(userId: string) { const token=crypto.randomBytes(32).toString("base64url"); await prisma.session.create({data:{tokenHash:hash(token),userId,expiresAt:new Date(Date.now()+SESSION_DAYS*86400000)}}); const jar=await cookies(); jar.set(SESSION_COOKIE,token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:SESSION_DAYS*86400}); return token; }
export async function clearSession() { const jar=await cookies(); const token=jar.get(SESSION_COOKIE)?.value; if(token) await prisma.session.deleteMany({where:{tokenHash:hash(token)}}); jar.delete(SESSION_COOKIE); }
export async function getCurrentUser() { const token=(await cookies()).get(SESSION_COOKIE)?.value; if(!token)return null; const session=await prisma.session.findUnique({where:{tokenHash:hash(token)},include:{user:{include:{onboarding:true,membership:true}}}}); if(!session)return null; if(session.expiresAt<=new Date()){await prisma.session.delete({where:{id:session.id}});return null;} return session.user; }
export async function requireUser() { const user=await getCurrentUser(); if(!user)redirect("/login"); return user; }
export async function requireAdmin() { const user=await requireUser(); if(user.role!=="ADMIN")redirect("/dashboard"); return user; }
export async function requirePro() { const user=await requireUser(); if(!user.membership || !["PRO","ELITE"].includes(user.membership.tier))redirect("/dashboard"); return user; }
export async function requireApiUser() { const user=await getCurrentUser(); if(!user)throw new Error("UNAUTHORIZED"); return user; }
export async function createPasswordReset(userId:string){const token=crypto.randomBytes(32).toString("base64url");await prisma.passwordResetToken.create({data:{tokenHash:hash(token),userId,expiresAt:new Date(Date.now()+RESET_HOURS*3600000)}});return token;}
export function hashToken(token:string){return hash(token);}
