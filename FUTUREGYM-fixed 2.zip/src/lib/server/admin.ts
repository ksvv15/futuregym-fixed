import "server-only";
import { requireAdmin } from "@/lib/server/auth";
export async function adminUser(){return requireAdmin();}
