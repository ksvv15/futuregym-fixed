export const motionVariants = {
  fadeIn: { hidden: { opacity: 0 }, visible: { opacity: 1 } },
  slideUp: { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } },
  scale: { hidden: { opacity: 0, scale: 0.96 }, visible: { opacity: 1, scale: 1 } },
  stagger: { hidden: {}, visible: { transition: { staggerChildren: 0.08 } } },
};

export const motionTransition = { duration: 0.55, ease: "easeOut" } as const;
