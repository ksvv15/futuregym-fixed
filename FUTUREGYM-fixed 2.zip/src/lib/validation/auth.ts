import { z } from "zod";
export const loginSchema = z.object({ email: z.email("validation.email"), password: z.string().min(8, "validation.password") });
export const signupSchema = z.object({ name: z.string().min(2, "validation.name"), email: z.email("validation.email"), password: z.string().min(8, "validation.password") });
export type LoginInput = z.infer<typeof loginSchema>;
export type SignupInput = z.infer<typeof signupSchema>;
