import { z } from "zod";

export const foodInterpretationSchema = z.object({
  text: z.string().trim().min(2).max(1000),
  source: z.enum(["TEXT", "VOICE"]).default("TEXT"),
  locale: z.enum(["en", "hi", "ar"]).default("en"),
});

export const nutritionResultSchema = z.object({
  foods: z.array(z.object({
    food: z.string().min(1).max(120),
    quantity: z.string().min(1).max(120),
    calories: z.number().min(0).max(3000),
    proteinG: z.number().min(0).max(200),
    carbsG: z.number().min(0).max(300),
    fatG: z.number().min(0).max(200),
    fiberG: z.number().min(0).max(100),
  })).min(1).max(30),
  summary: z.string().max(600).default(""),
});
