import { z } from "zod";
export const signupPhase3Schema=z.object({name:z.string().min(2,"validation.name"),email:z.email("validation.email"),password:z.string().min(8,"validation.password"),phone:z.string().min(7,"validation.phone")});
export const loginPhase3Schema=z.object({email:z.email("validation.email"),password:z.string().min(8,"validation.password")});
export const onboardingSchema=z.object({name:z.string().min(2),email:z.email(),phone:z.string().min(7),age:z.coerce.number().int().min(13).max(100),heightCm:z.coerce.number().min(100).max(240),currentWeightKg:z.coerce.number().min(30).max(300),targetWeightKg:z.coerce.number().min(30).max(300),goal:z.enum(["WEIGHT_LOSS","WEIGHT_GAIN","MUSCLE_BUILDING","GENERAL_FITNESS","STRENGTH","FLEXIBILITY"]),activityLevel:z.enum(["SEDENTARY","LIGHT","MODERATE","ACTIVE","VERY_ACTIVE"]),workoutFrequency:z.coerce.number().int().min(0).max(14),dietPreference:z.enum(["NONE","VEGETARIAN","VEGAN","HALAL","HIGH_PROTEIN","OTHER"])});
export const forgotPasswordSchema=z.object({email:z.email("validation.email")});
export const resetPasswordSchema=z.object({token:z.string().min(20),password:z.string().min(8,"validation.password")});
export type OnboardingInput=z.infer<typeof onboardingSchema>;
