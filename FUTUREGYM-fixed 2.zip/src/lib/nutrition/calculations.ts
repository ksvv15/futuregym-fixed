export type NutritionGoal = "WEIGHT_LOSS" | "WEIGHT_GAIN" | "MUSCLE_BUILDING" | "GENERAL_FITNESS" | "STRENGTH" | "FLEXIBILITY" | "MAINTENANCE";

export type NutritionProfile = {
  age: number;
  heightCm: number;
  weightKg: number;
  activityLevel: "SEDENTARY" | "LIGHT" | "MODERATE" | "ACTIVE" | "VERY_ACTIVE";
  goal: NutritionGoal;
};

const activityFactors = {
  SEDENTARY: 1.2,
  LIGHT: 1.375,
  MODERATE: 1.55,
  ACTIVE: 1.725,
  VERY_ACTIVE: 1.9,
} as const;

export function estimateNutritionTargets(profile: NutritionProfile) {
  // Sex is not collected in the current onboarding model. This uses the midpoint
  // of the two Mifflin-St Jeor constants, so the result is explicitly an estimate.
  const bmr = 10 * profile.weightKg + 6.25 * profile.heightCm - 5 * profile.age - 76.5;
  const maintenance = Math.round(bmr * activityFactors[profile.activityLevel]);
  const modifiers: Record<NutritionGoal, number> = {
    WEIGHT_LOSS: 0.85,
    WEIGHT_GAIN: 1.10,
    MUSCLE_BUILDING: 1.05,
    GENERAL_FITNESS: 1,
    STRENGTH: 1.05,
    FLEXIBILITY: 1,
    MAINTENANCE: 1,
  };
  const rawCalories = Math.round(maintenance * modifiers[profile.goal]);
  const calories = Math.min(4000, Math.max(1500, rawCalories));
  const proteinG = Math.round(profile.weightKg * (profile.goal === "WEIGHT_LOSS" || profile.goal === "MUSCLE_BUILDING" || profile.goal === "STRENGTH" ? 1.8 : 1.6));
  const fatG = Math.round((calories * 0.27) / 9);
  const carbsG = Math.max(80, Math.round((calories - proteinG * 4 - fatG * 9) / 4));
  return { bmr: Math.max(0, Math.round(bmr)), maintenance, calories, proteinG, carbsG, fatG, estimated: true };
}
