import { nutritionResultSchema } from "@/lib/validation/nutrition";

const foods = [
  { keys: ["egg", "eggs", "अंडा", "अंडे", "بيض", "البيض"], unit: "egg", cal: 72, proteinG: 6.3, carbsG: .4, fatG: 4.8, fiberG: 0 },
  { keys: ["roti", "roti", "chapati", "chapatis", "रोटी", "रोटियां", "خبز", "روتي"], unit: "roti", cal: 105, proteinG: 3.2, carbsG: 22, fatG: .8, fiberG: 2.5 },
  { keys: ["dal", "daal", "दाल", "عدس"], unit: "bowl", cal: 155, proteinG: 9, carbsG: 20, fatG: 3.5, fiberG: 6 },
  { keys: ["paneer", "पनीर", "جبن بانير"], unit: "100 g", cal: 265, proteinG: 18, carbsG: 6, fatG: 20, fiberG: 0 },
  { keys: ["milk", "दूध", "दूध", "حليب"], unit: "250 ml", cal: 150, proteinG: 8, carbsG: 12, fatG: 8, fiberG: 0 },
  { keys: ["banana", "केला", "موز"], unit: "banana", cal: 105, proteinG: 1.3, carbsG: 27, fatG: .4, fiberG: 3.1 },
  { keys: ["rice", "चावल", "भात", "أرز"], unit: "bowl", cal: 180, proteinG: 3.5, carbsG: 40, fatG: .4, fiberG: .6 },
];

function quantityFor(text: string, key: string) {
  const match = text.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(?:x|times|${key})?`, "i"));
  return match ? Number(match[1]) : 1;
}

export function fallbackInterpret(text: string) {
  const lower = text.toLocaleLowerCase();
  const matched = foods.filter((f) => f.keys.some((key) => lower.includes(key.toLocaleLowerCase())));
  const result = matched.map((f) => {
    const key = f.keys.find((k) => lower.includes(k.toLocaleLowerCase())) ?? f.keys[0];
    const qty = quantityFor(lower, key);
    return { food: key, quantity: `${qty} ${f.unit}${qty === 1 ? "" : "s"}`, calories: Math.round(f.cal * qty), proteinG: +(f.proteinG * qty).toFixed(1), carbsG: +(f.carbsG * qty).toFixed(1), fatG: +(f.fatG * qty).toFixed(1), fiberG: +(f.fiberG * qty).toFixed(1) };
  });
  if (!result.length) return null;
  return nutritionResultSchema.parse({ foods: result });
}
