import "server-only";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import path from "node:path";

const root = path.resolve(process.cwd(), ".private-storage", "progress-photos");

function safePath(key: string) {
  const target = path.resolve(root, key);
  if (target !== root && !target.startsWith(`${root}${path.sep}`)) {
    throw new Error("Invalid storage key");
  }
  return target;
}

export async function savePrivateFile(key: string, data: Buffer) {
  const target = safePath(key);
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, data, { flag: "wx" });
  return target;
}

export async function readPrivateFile(key: string) {
  return readFile(safePath(key));
}

export async function deletePrivateFile(key: string) {
  try { await unlink(safePath(key)); } catch { /* already absent */ }
}
