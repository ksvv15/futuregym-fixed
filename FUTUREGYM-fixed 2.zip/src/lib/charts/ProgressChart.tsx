"use client";
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
const data = [{name:"W1",value:72},{name:"W2",value:74},{name:"W3",value:75},{name:"W4",value:77}];
export function ProgressChart(){return <div className="h-56 w-full"><ResponsiveContainer width="100%" height="100%"><LineChart data={data}><XAxis dataKey="name" stroke="#8b9198" /><YAxis stroke="#8b9198" hide /><Tooltip contentStyle={{background:"#1d2124",border:"1px solid #31373c",borderRadius:8,color:"#f4f2ed"}} /><Line type="monotone" dataKey="value" stroke="#ff6b35" strokeWidth={2} dot={false} /></LineChart></ResponsiveContainer></div>}
