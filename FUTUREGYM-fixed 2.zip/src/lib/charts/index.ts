export const chartConfig = { responsive: true, animation: false } as const;
