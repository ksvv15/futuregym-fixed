"use client";
import { useMessages } from "@/components/i18n/LanguageSwitcher";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { whatsappUrl } from "@/lib/whatsapp";
export default function Page(){const t=useMessages();return <main className="min-h-[70vh] py-24 md:py-32"><Container><SectionHeading eyebrow={t.sections.contactEyebrow} title={t.sections.contactTitle}>{t.sections.contactBody}</SectionHeading><div className="mt-12 rounded-card border border-border bg-surface p-8"><p className="text-xs uppercase tracking-[.18em] text-muted">{t.sections.location}</p><p className="mt-3 text-2xl font-bold">{t.sections.dubaiTitle}</p><a className="mt-8 inline-flex" href={whatsappUrl(t.whatsapp.contact)} target="_blank" rel="noreferrer"><Button>{t.hero.whatsapp}</Button></a></div></Container></main>}
