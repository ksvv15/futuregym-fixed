"use client";
import Link from "next/link";
import { useMessages } from "@/components/i18n/LanguageSwitcher";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
export default function Page(){const t=useMessages();return <main className="min-h-[70vh] py-24 md:py-32"><Container><SectionHeading eyebrow={t.sections.aboutEyebrow} title={t.sections.aboutTitle}>{t.sections.aboutBody}</SectionHeading><div className="mt-12 grid gap-5 md:grid-cols-2"><div className="rounded-card border border-border bg-surface p-8"><p className="text-5xl font-black text-accent">01</p><p className="mt-6 text-sm leading-7 text-muted">{t.sections.whyItems[0]}</p></div><div className="rounded-card border border-border bg-surface-2 p-8"><p className="text-5xl font-black text-accent">02</p><p className="mt-6 text-sm leading-7 text-muted">{t.sections.whyItems[1]}</p></div></div><Link href="/membership" className="mt-8 inline-flex"><Button>{t.sections.membershipCta}</Button></Link></Container></main>}
