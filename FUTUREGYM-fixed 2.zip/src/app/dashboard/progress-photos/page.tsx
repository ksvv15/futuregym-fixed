import { requireUser } from "@/lib/server/auth"; import { prisma } from "@/lib/server/prisma"; import { PhotoTimeline } from "@/components/dashboard/photos/PhotoTimeline";
export default async function Photos(){const u=await requireUser();const photos=await prisma.progressPhoto.findMany({where:{userId:u.id},orderBy:{capturedAt:"desc"}});return <PhotoTimeline initial={photos}/>}
