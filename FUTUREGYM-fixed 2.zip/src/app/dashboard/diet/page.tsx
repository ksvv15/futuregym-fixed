import { redirect } from "next/navigation";
import { requireUser } from "@/lib/server/auth";
import { NutritionDashboard } from "@/components/dashboard/nutrition/NutritionDashboard";
export default async function DietPage(){const user=await requireUser();if(!user.onboarding)redirect("/onboarding");return <NutritionDashboard profile={user.onboarding}/>}
