import { requireUser } from "@/lib/server/auth"; import { Container } from "@/components/ui/Container"; import { SettingsPanel } from "@/components/dashboard/SettingsPanel";
export default async function Settings(){await requireUser();return <main className="py-14"><Container><SettingsPanel/></Container></main>}
