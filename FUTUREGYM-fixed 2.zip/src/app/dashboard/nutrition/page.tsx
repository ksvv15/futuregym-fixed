export { default } from "@/app/dashboard/diet/page";
