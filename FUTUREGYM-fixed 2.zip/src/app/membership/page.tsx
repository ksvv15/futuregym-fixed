"use client";
import Link from "next/link";
import { useMessages } from "@/components/i18n/LanguageSwitcher";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { whatsappUrl } from "@/lib/whatsapp";
export default function Page(){const t=useMessages();const tiers=[t.sections.basic,t.sections.pro,t.sections.elite];return <main className="min-h-[70vh] py-24 md:py-32"><Container><SectionHeading eyebrow={t.sections.membershipEyebrow} title={t.sections.membershipTitle}>{t.sections.membershipBody}</SectionHeading><div className="mt-12 grid gap-5 md:grid-cols-3">{tiers.map((tier)=><Card key={tier} className="p-8"><h2 className="text-2xl font-black">{tier}</h2><p className="mt-8 text-xs uppercase tracking-[.15em] text-muted">{t.sections.from}</p><div className="mt-8 flex gap-2"><Link href="/signup" className="flex-1"><Button className="w-full">{t.sections.membershipCta}</Button></Link><a href={whatsappUrl(t.whatsapp.membership.replace("{tier}",tier))} target="_blank" rel="noreferrer"><Button variant="ghost">{t.sections.whatsapp}</Button></a></div></Card>)}</div></Container></main>}
