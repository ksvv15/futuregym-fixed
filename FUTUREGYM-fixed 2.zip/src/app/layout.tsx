import type { Metadata } from "next";
import "./globals.css";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { PageTransition } from "@/components/animation/PageTransition";
export const metadata: Metadata = { title: "FUTUREGYM — Train Beyond Ordinary", description: "Premium Future Gym performance club." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en" dir="ltr"><body><Navbar /><PageTransition>{children}</PageTransition><Footer /></body></html>; }
