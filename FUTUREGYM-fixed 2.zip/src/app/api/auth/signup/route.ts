import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/prisma";
import { createSession, makePasswordHash } from "@/lib/server/auth";
import { signupPhase3Schema } from "@/lib/validation/phase3";
export async function POST(req:Request){try{const parsed=signupPhase3Schema.safeParse(await req.json());if(!parsed.success)return NextResponse.json({error:"validation.invalid"},{status:400});const {name,email,password,phone}=parsed.data;const exists=await prisma.user.findUnique({where:{email:email.toLowerCase()}});if(exists)return NextResponse.json({error:"auth.emailExists"},{status:409});const user=await prisma.user.create({data:{name,email:email.toLowerCase(),phone,passwordHash:await makePasswordHash(password),membership:{create:{tier:"BASIC"}}}});await createSession(user.id);return NextResponse.json({ok:true,user:{id:user.id,name:user.name,email:user.email}});}catch{return NextResponse.json({error:"common.error"},{status:500});}}
