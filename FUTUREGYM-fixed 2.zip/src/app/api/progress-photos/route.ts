import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/server/auth";
import { prisma } from "@/lib/server/prisma";
import { savePrivateFile } from "@/lib/storage/private";
import crypto from "node:crypto";

const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = new Map<string, { ext: string; mime: string; signature: (b: Buffer) => boolean }>([
  ["image/jpeg", { ext: "jpg", mime: "image/jpeg", signature: b => b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff }],
  ["image/png", { ext: "png", mime: "image/png", signature: b => b.length >= 8 && b.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])) }],
  ["image/webp", { ext: "webp", mime: "image/webp", signature: b => b.length >= 12 && b.toString("ascii", 0, 4) === "RIFF" && b.toString("ascii", 8, 12) === "WEBP" }],
]);

export async function GET() {
  try {
    const u = await requireApiUser();
    const rows = await prisma.progressPhoto.findMany({ where: { userId: u.id }, orderBy: { capturedAt: "desc" } });
    return NextResponse.json(rows);
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}

export async function POST(req: Request) {
  try {
    const u = await requireApiUser();
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "Image required" }, { status: 400 });
    if (file.size <= 0 || file.size > MAX_BYTES) return NextResponse.json({ error: "Image must be between 1 byte and 8 MB" }, { status: 400 });
    const format = ALLOWED.get(file.type);
    if (!format) return NextResponse.json({ error: "Only JPEG, PNG, and WebP images are supported" }, { status: 400 });
    const data = Buffer.from(await file.arrayBuffer());
    if (!format.signature(data)) return NextResponse.json({ error: "The uploaded file is not a valid image" }, { status: 400 });
    const key = `${u.id}/${crypto.randomUUID()}.${format.ext}`;
    await savePrivateFile(key, data);
    try {
      const row = await prisma.progressPhoto.create({ data: { userId: u.id, storageKey: key, mimeType: format.mime } });
      return NextResponse.json(row, { status: 201 });
    } catch (error) {
      await import("@/lib/storage/private").then(({ deletePrivateFile }) => deletePrivateFile(key));
      throw error;
    }
  } catch { return NextResponse.json({ error: "Unable to upload photo" }, { status: 400 }); }
}
