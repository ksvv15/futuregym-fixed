import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/server/auth";
import { prisma } from "@/lib/server/prisma";
import { nutritionResultSchema, foodInterpretationSchema } from "@/lib/validation/nutrition";
import { z } from "zod";

const saveSchema = z.object({ text: foodInterpretationSchema.shape.text, source: z.enum(["TEXT", "VOICE"]), result: nutritionResultSchema });

export async function GET() {
  try {
    const user = await requireApiUser();
    const meals = await prisma.mealLog.findMany({ where: { userId: user.id }, orderBy: { mealDate: "desc" }, take: 100 });
    return NextResponse.json(meals);
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}

export async function POST(request: Request) {
  try {
    const user = await requireApiUser();
    const body = saveSchema.parse(await request.json());
    const totals = body.result.foods.reduce((a, f) => ({ calories: a.calories + f.calories, proteinG: a.proteinG + f.proteinG, carbsG: a.carbsG + f.carbsG, fatG: a.fatG + f.fatG, fiberG: a.fiberG + f.fiberG }), { calories: 0, proteinG: 0, carbsG: 0, fatG: 0, fiberG: 0 });
    const date = new Date(new Date().toDateString());
    const [meal] = await prisma.$transaction([
      prisma.mealLog.create({ data: { userId: user.id, rawText: body.text, source: body.source, foodsJson: body.result.foods, ...totals } }),
      prisma.dailyMetric.upsert({ where: { userId_date: { userId: user.id, date } }, update: { calories: { increment: totals.calories }, proteinG: { increment: totals.proteinG }, carbsG: { increment: totals.carbsG }, fatG: { increment: totals.fatG }, fiberG: { increment: totals.fiberG } }, create: { userId: user.id, date, calories: totals.calories, proteinG: totals.proteinG, carbsG: totals.carbsG, fatG: totals.fatG, fiberG: totals.fiberG } })
    ]);
    return NextResponse.json(meal, { status: 201 });
  } catch { return NextResponse.json({ error: "Could not save meal." }, { status: 400 }); }
}
