import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/server/auth";
import { foodInterpretationSchema, nutritionResultSchema } from "@/lib/validation/nutrition";
import { fallbackInterpret } from "@/lib/nutrition/fallback";

const limiter = new Map<string, { count: number; reset: number }>();

function allowed(id: string) {
  const now = Date.now(); const current = limiter.get(id);
  if (!current || current.reset < now) { limiter.set(id, { count: 1, reset: now + 60_000 }); return true; }
  if (current.count >= 20) return false; current.count += 1; return true;
}

export async function POST(request: Request) {
  try {
    const user = await requireApiUser();
    if (!allowed(user.id)) return NextResponse.json({ error: "Too many nutrition requests. Please wait a moment." }, { status: 429 });
    const body = foodInterpretationSchema.parse(await request.json());
    const apiKey = process.env.AI_API_KEY;
    const apiUrl = process.env.AI_API_URL;
    const model = process.env.AI_MODEL || "gpt-4o-mini";
    if (!apiKey || !apiUrl) {
      const fallback = fallbackInterpret(body.text);
      if (!fallback) return NextResponse.json({ error: "AI is unavailable and the local food fallback could not identify those foods. Please check the text and try again." }, { status: 503 });
      return NextResponse.json({ ...fallback, source: "fallback", estimated: true });
    }
    const response = await fetch(apiUrl, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` }, body: JSON.stringify({ model, temperature: 0.1, response_format: { type: "json_object" }, messages: [{ role: "system", content: `Interpret natural-language food logs. Return ONLY JSON matching {foods:[{food,quantity,calories,proteinG,carbsG,fatG,fiberG}],summary}. Nutrition values are estimates. Never make medical claims. Support English, Hindi, and Arabic. Return the summary in the requested locale: ${body.locale}.` }, { role: "user", content: body.text }] }), cache: "no-store" });
    if (!response.ok) throw new Error("AI provider error");
    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;
    const parsed = nutritionResultSchema.parse(typeof content === "string" ? JSON.parse(content) : content);
    return NextResponse.json({ ...parsed, source: "ai", estimated: true });
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ error: "Nutrition interpretation failed. Please try again or use the text fallback." }, { status: 400 });
  }
}
