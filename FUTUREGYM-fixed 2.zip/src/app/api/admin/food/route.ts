import {crud} from '../_crud';
export const GET=(r:Request)=>crud('food','GET',r); export const POST=(r:Request)=>crud('food','POST',r); export const PUT=(r:Request)=>crud('food','PUT',r); export const PATCH=(r:Request)=>crud('food','PATCH',r);
