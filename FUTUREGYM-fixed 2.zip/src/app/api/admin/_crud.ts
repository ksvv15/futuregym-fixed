import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/prisma";
import { adminUser } from "@/lib/server/admin";

const tier = z.enum(["BASIC", "PRO", "ELITE"]);
const goal = z.enum(["WEIGHT_LOSS", "WEIGHT_GAIN", "MUSCLE_BUILDING", "GENERAL_FITNESS", "STRENGTH", "FLEXIBILITY"]);
const idSchema = z.string().cuid();
const schemas: Record<string, z.ZodTypeAny> = {
  memberships: z.object({ id: idSchema.optional(), name: z.string().trim().min(2).max(80), tier, price: z.coerce.number().finite().min(0).max(10000000), durationDays: z.coerce.number().int().min(1).max(3650), benefits: z.array(z.string().trim().min(1).max(200)).max(50), proFeatures: z.array(z.string().trim().min(1).max(200)).max(50), active: z.boolean().optional() }),
  workouts: z.object({ id: idSchema.optional(), name: z.string().trim().min(2).max(120), muscleGroup: z.string().trim().min(2).max(80), difficulty: z.string().trim().min(2).max(40), instructions: z.string().trim().min(2).max(2000), active: z.boolean().optional() }),
  food: z.object({ id: idSchema.optional(), name: z.string().trim().min(2).max(120), calories100: z.coerce.number().finite().min(0).max(2000), protein100: z.coerce.number().finite().min(0).max(200), carbs100: z.coerce.number().finite().min(0).max(300), fat100: z.coerce.number().finite().min(0).max(200), fiber100: z.coerce.number().finite().min(0).max(100), active: z.boolean().optional() }),
  reviews: z.object({ id: idSchema.optional(), name: z.string().trim().min(2).max(120), rating: z.coerce.number().int().min(1).max(5), text: z.string().trim().min(2).max(1000), active: z.boolean().optional() }),
  gallery: z.object({ id: idSchema.optional(), type: z.enum(["IMAGE", "VIDEO"]), url: z.string().url().max(2048), alt: z.string().trim().min(2).max(200), active: z.boolean().optional() }),
  content: z.object({ id: idSchema.optional(), key: z.string().trim().min(2).max(120), value: z.unknown() }),
};

export async function crud(kind: string, method: string, req: Request) {
  try {
    await adminUser();
    const schema = schemas[kind];
    if (!schema) return NextResponse.json({ error: "Unsupported resource" }, { status: 404 });
    if (method === "GET") {
      const result = kind === "memberships" ? await prisma.membershipPlan.findMany({ orderBy: { createdAt: "desc" } }) :
        kind === "workouts" ? await prisma.exercise.findMany({ orderBy: { createdAt: "desc" } }) :
        kind === "food" ? await prisma.foodItem.findMany({ orderBy: { createdAt: "desc" } }) :
        kind === "reviews" ? await prisma.review.findMany({ orderBy: { createdAt: "desc" } }) :
        kind === "gallery" ? await prisma.galleryItem.findMany({ orderBy: { createdAt: "desc" } }) :
        await prisma.siteContent.findMany({ orderBy: { key: "asc" } });
      return NextResponse.json(result);
    }
    const raw = await req.json();
    const parsed = schema.safeParse(raw);
    if (!parsed.success) return NextResponse.json({ error: "Invalid request", issues: parsed.error.flatten() }, { status: 400 });
    const data = parsed.data as Record<string, unknown>;
    const id = typeof data.id === "string" ? data.id : undefined;
    delete data.id;
    let result: unknown;
    if (kind === "memberships") {
      if (method === "POST") result = await prisma.membershipPlan.create({ data: { ...data, price: String(data.price), benefits: data.benefits, proFeatures: data.proFeatures } as never });
      else if (method === "PUT" && id) result = await prisma.membershipPlan.update({ where: { id }, data: { ...data, price: String(data.price) } as never });
      else if (method === "PATCH" && id) result = await prisma.membershipPlan.update({ where: { id }, data: { active: data.active } });
    } else if (kind === "workouts") {
      if (method === "POST") result = await prisma.exercise.create({ data: data as never });
      else if (method === "PUT" && id) result = await prisma.exercise.update({ where: { id }, data: data as never });
      else if (method === "PATCH" && id) result = await prisma.exercise.update({ where: { id }, data: { active: data.active } });
    } else if (kind === "food") {
      if (method === "POST") result = await prisma.foodItem.create({ data: data as never });
      else if (method === "PUT" && id) result = await prisma.foodItem.update({ where: { id }, data: data as never });
      else if (method === "PATCH" && id) result = await prisma.foodItem.update({ where: { id }, data: { active: data.active } });
    } else if (kind === "reviews") {
      if (method === "POST") result = await prisma.review.create({ data: data as never });
      else if (method === "PUT" && id) result = await prisma.review.update({ where: { id }, data: data as never });
      else if (method === "PATCH" && id) result = await prisma.review.update({ where: { id }, data: { active: data.active } });
    } else if (kind === "gallery") {
      if (method === "POST") result = await prisma.galleryItem.create({ data: data as never });
      else if (method === "PUT" && id) result = await prisma.galleryItem.update({ where: { id }, data: data as never });
      else if (method === "PATCH" && id) result = await prisma.galleryItem.update({ where: { id }, data: { active: data.active } });
    } else {
      if (method === "POST") result = await prisma.siteContent.create({ data: data as never });
      else if (method === "PUT" && id) result = await prisma.siteContent.update({ where: { id }, data: { key: data.key, value: data.value } });
      else if (method === "PATCH" && id) result = await prisma.siteContent.update({ where: { id }, data: { value: data.value } });
    }
    if (!result) return NextResponse.json({ error: "Invalid method or missing id" }, { status: 400 });
    return NextResponse.json(result);
  } catch (error) {
    const status = error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 403;
    return NextResponse.json({ error: status === 401 ? "Unauthorized" : "Forbidden" }, { status });
  }
}
