import {crud} from '../_crud';
export const GET=(r:Request)=>crud('content','GET',r); export const POST=(r:Request)=>crud('content','POST',r); export const PUT=(r:Request)=>crud('content','PUT',r); export const PATCH=(r:Request)=>crud('content','PATCH',r);
