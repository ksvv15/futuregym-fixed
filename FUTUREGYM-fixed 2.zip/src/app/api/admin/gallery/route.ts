import {crud} from '../_crud';
export const GET=(r:Request)=>crud('gallery','GET',r); export const POST=(r:Request)=>crud('gallery','POST',r); export const PUT=(r:Request)=>crud('gallery','PUT',r); export const PATCH=(r:Request)=>crud('gallery','PATCH',r);
