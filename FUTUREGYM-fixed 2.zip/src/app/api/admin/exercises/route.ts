import {crud} from '../_crud';
export const GET=(r:Request)=>crud('workouts','GET',r); export const POST=(r:Request)=>crud('workouts','POST',r); export const PUT=(r:Request)=>crud('workouts','PUT',r); export const PATCH=(r:Request)=>crud('workouts','PATCH',r);
export async function DELETE(req:Request){const {prisma}=await import('@/lib/server/prisma');const {adminUser}=await import('@/lib/server/admin');try{await adminUser();const {id}=await req.json();await prisma.exercise.delete({where:{id}});return Response.json({ok:true})}catch{return Response.json({error:'Forbidden'},{status:403})}}
