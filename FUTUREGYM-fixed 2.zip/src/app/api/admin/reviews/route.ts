import {crud} from '../_crud';
export const GET=(r:Request)=>crud('reviews','GET',r); export const POST=(r:Request)=>crud('reviews','POST',r); export const PUT=(r:Request)=>crud('reviews','PUT',r); export const PATCH=(r:Request)=>crud('reviews','PATCH',r);
