import {crud} from '../_crud';
export const GET=(r:Request)=>crud('memberships','GET',r); export const POST=(r:Request)=>crud('memberships','POST',r); export const PUT=(r:Request)=>crud('memberships','PUT',r); export const PATCH=(r:Request)=>crud('memberships','PATCH',r);
