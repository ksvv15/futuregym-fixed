import { NextResponse } from "next/server";
import { z } from "zod";
import { adminUser } from "@/lib/server/admin";
import { prisma } from "@/lib/server/prisma";

const actionSchema = z.object({ id: z.string().cuid(), action: z.enum(["SET_TIER", "ACTIVATE", "PAUSE", "CANCEL", "RENEW"]), tier: z.enum(["BASIC", "PRO", "ELITE"]).optional() });

export async function GET() {
  try { await adminUser(); const rows = await prisma.user.findMany({ where: { role: "USER" }, include: { onboarding: true, membership: true }, orderBy: { createdAt: "desc" } }); return NextResponse.json(rows); }
  catch { return NextResponse.json({ error: "Forbidden" }, { status: 403 }); }
}

export async function PATCH(req: Request) {
  try {
    await adminUser();
    const input = actionSchema.safeParse(await req.json());
    if (!input.success) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
    const { id, action, tier } = input.data;
    const member = await prisma.user.findUnique({ where: { id }, select: { role: true, membership: true } });
    if (!member || member.role !== "USER") return NextResponse.json({ error: "Member not found" }, { status: 404 });
    const now = new Date();
    if (action === "SET_TIER") {
      if (!tier) return NextResponse.json({ error: "Tier required" }, { status: 400 });
      const expiresAt = new Date(now.getTime() + 30 * 86400000);
      await prisma.$transaction([
        prisma.membership.upsert({ where: { userId: id }, create: { userId: id, tier, active: true, startsAt: now, expiresAt }, update: { tier, active: true } }),
        prisma.membershipHistory.create({ data: { userId: id, tier, startsAt: now, expiresAt, action: "PLAN_CHANGE" } }),
      ]);
    } else if (action === "ACTIVATE") {
      await prisma.membership.upsert({ where: { userId: id }, create: { userId: id, tier: "BASIC", active: true, startsAt: now, expiresAt: new Date(now.getTime() + 30 * 86400000) }, update: { active: true } });
    } else if (action === "PAUSE" || action === "CANCEL") {
      await prisma.membership.updateMany({ where: { userId: id }, data: { active: false } });
    } else {
      const current = member.membership;
      const currentTier = current?.tier ?? "BASIC";
      const base = current?.expiresAt && current.expiresAt > now ? current.expiresAt : now;
      const expiresAt = new Date(base.getTime() + 30 * 86400000);
      await prisma.$transaction([
        prisma.membership.upsert({ where: { userId: id }, create: { userId: id, tier: currentTier, active: true, startsAt: now, expiresAt }, update: { active: true, expiresAt } }),
        prisma.membershipHistory.create({ data: { userId: id, tier: currentTier, startsAt: now, expiresAt, action: "RENEW" } }),
      ]);
    }
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Unable to update member" }, { status: 400 }); }
}
