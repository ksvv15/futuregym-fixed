import {crud} from '../_crud';
export const GET=(r:Request)=>crud('workouts','GET',r); export const POST=(r:Request)=>crud('workouts','POST',r); export const PUT=(r:Request)=>crud('workouts','PUT',r); export const PATCH=(r:Request)=>crud('workouts','PATCH',r);
