import { NextResponse } from "next/server";
export function GET() { return NextResponse.json({ service: "futuregym", phase: 1, status: "ok" }); }
