import {AdminHeader} from '@/components/admin/AdminUI'; import {CrudManager} from '@/components/admin/CrudManager';
export default function Page(){return <><AdminHeader title="Memberships" subtitle="Manage Basic, Pro and Elite plans."/><CrudManager kind="memberships"/></>}
