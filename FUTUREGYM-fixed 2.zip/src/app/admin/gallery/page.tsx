import {AdminHeader} from '@/components/admin/AdminUI'; import {CrudManager} from '@/components/admin/CrudManager';
export default function Page(){return <><AdminHeader title="Gallery" subtitle="Manage website images and videos."/><CrudManager kind="gallery"/></>}
