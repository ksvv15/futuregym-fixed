import { requireAdmin } from "@/lib/server/auth";
import { AdminShell } from "@/components/admin/AdminShell";
export default async function AdminLayout({children}:{children:React.ReactNode}){await requireAdmin();return <AdminShell>{children}</AdminShell>}
