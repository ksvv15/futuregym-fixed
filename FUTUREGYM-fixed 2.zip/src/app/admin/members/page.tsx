import {MembersManager} from '@/components/admin/MembersManager'; import {AdminHeader} from '@/components/admin/AdminUI';
export default function Page(){return <><AdminHeader title="Members" subtitle="Search, segment and manage member lifecycle."/><MembersManager/></>}
