import {AdminHeader} from '@/components/admin/AdminUI'; import {CrudManager} from '@/components/admin/CrudManager';
export default function Page(){return <><AdminHeader title="Reviews" subtitle="Manage member testimonials and ratings."/><CrudManager kind="reviews"/></>}
