import {AdminHeader} from '@/components/admin/AdminUI'; import {CrudManager} from '@/components/admin/CrudManager'; import {MealTemplateManager} from '@/components/admin/MealTemplateManager';
export default function Page(){return <><AdminHeader title="Food" subtitle="Manage nutrition data and reusable meal templates."/><CrudManager kind="food"/><MealTemplateManager/></>}
