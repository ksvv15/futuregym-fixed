import {AdminHeader} from '@/components/admin/AdminUI'; import {CrudManager} from '@/components/admin/CrudManager'; import {TemplateManager} from '@/components/admin/TemplateManager';
export default function Page(){return <><AdminHeader title="Workouts" subtitle="Manage exercise library and reusable workout templates."/><CrudManager kind="exercises"/><TemplateManager/></>}
