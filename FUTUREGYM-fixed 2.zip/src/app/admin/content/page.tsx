import {AdminHeader} from '@/components/admin/AdminUI'; import {CrudManager} from '@/components/admin/CrudManager';
export default function Page(){return <><AdminHeader title="Website" subtitle="Content Manage homepage, services, FAQs and contact content."/><CrudManager kind="content"/></>}
