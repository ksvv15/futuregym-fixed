"use client";
import Link from "next/link";
import { useMessages } from "@/components/i18n/LanguageSwitcher";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
export default function Page(){const t=useMessages();return <main className="min-h-[70vh] py-24 md:py-32"><Container><SectionHeading eyebrow={t.sections.servicesEyebrow} title={t.sections.servicesTitle}>{t.sections.servicesBody}</SectionHeading><div className="mt-12 grid gap-5 md:grid-cols-2"><Card className="p-8"><p className="text-xs text-accent">01</p><h2 className="mt-4 text-3xl font-black">{t.sections.gym}</h2><p className="mt-4 text-sm leading-7 text-muted">{t.sections.gymBody}</p></Card><Card className="p-8"><p className="text-xs text-accent">02</p><h2 className="mt-4 text-3xl font-black">{t.sections.yoga}</h2><p className="mt-4 text-sm leading-7 text-muted">{t.sections.yogaBody}</p></Card></div><Link href="/contact" className="mt-8 inline-flex"><Button>{t.sections.contactCta}</Button></Link></Container></main>}
