# FUTURE GYM — Phase 4

Phase 4 extends the existing Phase 3 architecture. It adds workout planning/history, a persistent workout timer, Recharts activity analytics, body measurements, and private progress photos.

## Routes
- `/dashboard/workouts`
- `/dashboard/workout-history`
- `/dashboard/progress`
- `/dashboard/progress-photos`

## Server protection
All Phase 4 dashboard routes use the existing server-side session guard. Workout/progress APIs call `requireApiUser()` before database access. Progress photo files are never exposed from `/public`; they are streamed through an authenticated route that checks ownership.

## Storage
The development storage adapter writes private photo bytes under `.private-storage/progress-photos` and keeps only a storage key in PostgreSQL. The adapter is intentionally isolated in `src/lib/storage/private.ts` so production object storage can be substituted without changing the photo UI/API contract.

## Database
Phase 4 adds:
- `WorkoutPlan`
- `PlannedWorkout`
- `PlannedExercise`
- `BodyMeasurement`
- `ProgressPhoto`
- `WorkoutSession.endedAt`

Run `pnpm prisma generate` and `pnpm prisma db push` against a configured PostgreSQL database before using persistent features.
